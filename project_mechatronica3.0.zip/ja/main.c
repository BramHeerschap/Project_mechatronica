#ifndef F_CPU
#define F_CPU	16000000ul
#endif

#include <util/delay.h>
#include <avr/io.h>
#include "servo.h"
#include "h_bridge.h"

#define IRV         PC3 //D34 IR sensor voorkant
#define IRA         PC5 //D32 IR sensor achterkant
#define LEDBR1      PA0 //D22 Rood boot 1
#define LEDBR2      PA2 //D24 Rood boot 2
#define LEDBR3      PA4 //D26 Rood boot 3
#define LEDBR4      PA6 //D28 Rood boot 4
#define LEDBG1      PA1 //D23 Groen boot 1
#define LEDBG2      PA3 //D25 Groen boot 2
#define LEDBG3      PA5 //D27 Groen boot 3
#define LEDBG4      PA7 //D29 Groen boot 4
#define LEDFR1      PC2 //D35 Rood fiets 1
#define LEDFR2      PC0 //D37 Rood fiets 2
#define KNOPNOOD    PC7 //D30 noodknop
#define BRUGOPEN    PC4 //D33 brugopen switch
#define BRUGDICHT   PC6 //D31 brugdicht switch

void init(void){
    init_h_bridge();
    init_servo();

    DDRA |= (1 <<LEDBR1);
    DDRA |= (1 <<LEDBR2);
    DDRA |= (1 <<LEDBR3);
    DDRA |= (1 <<LEDBR4);

    DDRA |= (1 <<LEDBG1);
    DDRA |= (1 <<LEDBG2);
    DDRA |= (1 <<LEDBG3);
    DDRA |= (1 <<LEDBG4);

    DDRC |= (1 <<LEDFR1);
    DDRC |= (1 <<LEDFR2);

    DDRC &= ~(1<<IRV);
    DDRC &= ~(1<<IRA);

    DDRC &= ~(1<<KNOPNOOD);

    DDRC &= ~(1<<BRUGOPEN);
    DDRC &= ~(1<<BRUGDICHT);

    PORTA |= (1 <<LEDBR1);
    PORTA |= (1 <<LEDBR2);
    PORTA |= (1 <<LEDBR3);
    PORTA |= (1 <<LEDBR4);
}
void noodknop(void){
    if((PINC & (1<<KNOPNOOD))!=0)
    {
        while(1){
            h_bridge_set_percentage(0);
            while(PINC &(1<<KNOPNOOD));

            if((PINC &(1<<KNOPNOOD))!=0){
                break;

            }
        }
    }
}


int main (void)
{
  init();


while(1){

    if(((PINC &(1<<IRA))== 0) && ((PINC & (1<<IRV))!=0)){

        PORTC |= (1 << LEDFR1); //de rode LEDs gaan aan
        PORTC |= (1 << LEDFR2);

        PORTA |= (1 <<LEDBG1); //de groene LEDs gaan aan
        PORTA |= (1 <<LEDBG2);
        PORTA |= (1 <<LEDBG3);
        PORTA |= (1 <<LEDBG4);

        _delay_ms (4000);
        servo1_set_percentage(-50);
        servo2_set_percentage(50);
        _delay_ms (1000);


        while ((PINC & (1<<BRUGOPEN)) == 0) //detecteren van de brug
            {
                _delay_ms(20);
                noodknop(); //Noodknop is actief
                h_bridge_set_percentage(50);
        }

        h_bridge_set_percentage(0); //brug blijft stil hangen
        PORTA &= ~(1<<LEDBR1); // de rode LEDs gaan uit
        PORTA &= ~(1<<LEDBR2);
        PORTA &= ~(1<<LEDBR3);
        PORTA &= ~(1<<LEDBR4);

        while((PINC & (1<<IRA))!=0);

        while((PINC & (1<<IRA)==0));

        PORTA |= (1 <<LEDBR1); // de rode LEDs gaan aan
        PORTA |= (1 <<LEDBR2);
        PORTA |= (1 <<LEDBR3);
        PORTA |= (1 <<LEDBR4);

        while ((PINC & (1<<BRUGDICHT)) == 0) //detecteren van de brug
            {
                _delay_ms(20);
                noodknop(); //Noodknop is actief
                h_bridge_set_percentage(-50);
        }

        servo1_set_percentage(50); //slagboom gaat weer open
        servo2_set_percentage(-50); //slagboom gaat weer open
        PORTA &= ~(1 << LEDFR1); // Rode LED voor fietsers gaan uit.
        PORTA &= ~(1 << LEDFR2);
        PORTA &= ~(1 << LEDBG1); // Groen boot gaat uit
        PORTA &= ~(1 << LEDBG2);
        PORTA &= ~(1 << LEDBG3);
        PORTA &= ~(1 << LEDBG4);
        }


    }
     return 0;
}


